import React from "react";
import { Table} from "antd";
import * as dat from "./data";

export default function TableComp() {
  return (
    <>
      <h1>Table</h1>
      <Table columns={dat.columns} dataSource={dat.dataSource} />
    </>
  );
}
