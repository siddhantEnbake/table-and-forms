import React from "react";
import "antd/dist/antd.css";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

import TableComp from "./component/TableComp";
import Forms from "./component/Forms";

function App() {
  return (
    <div className="App">
      <Router>
        <nav>
          <ul>
            <li>
              <Link to="/table">Table</Link>
            </li>
            <li>
              <Link to="/forms">Forms</Link>
            </li>
          </ul>
        </nav>

        
        <Switch>
          <Route exact path="/table">
            <TableComp />
          </Route>
          <Route exact path="/forms">
            <Forms />
          </Route>
        </Switch>
      </Router>
    </div>
  );
}

export default App;
